# 零散知识
> 一个数据库的排行榜
https://db-engines.com/en/ranking
> 

现在主要分为两种:
:::warning
**关系型数据库**
**比较有名的: * Oracle Database：甲骨文公司的RDBMS * SQL *Server：微软公司的RDBMS**
** * DB2：IBM公司的RDBMS**
** * PostgreSQL：开源的RDBMS **
*** MySQL：开源的RDBMS**
其他数据库包括:  
层次数据库,(HDB)
面向对象数据库(Object Oriented Database，OODB), 
XML数据库（XML Database，XMLDB）
键值存储系统（Key-Value Store，KVS），举例：MongoDB
**共5中数据库**

使用 RDBMS 时，最常见的系统结构就是客户端 / 服务器类型（C/S类型）
:::
> 能以二维表展现出来的就是关系型数据库


非关系型数据库(NOSQL)----> 存在内存的, 但是不能断点, 如果断点了, 数据就没了:
常见非关系型数据库:
> redis, MEmcached , MongoDB, HBase(大数据常用)

 
:::success
数据库5.0以后叫高版本, 只有高版本才有系统库, 一共四个
:::

## RDBMS零散知识
## 分类
根据 关系型数据库的种类, SQL语句分三类

1. DDL（Data Definition Language，数据定义语言）------> create, drop, alter
2. DML（Data Manipulation Language，数据操纵语言---->select, insert, update, delete
3. DCL（Data Control Language，数据控制语言)-----> commit(确认对数据库中的数据进行变更), rollback(取消对数据库中的数据进行变更),  grant(赋予用户操作权限), revoke(取消用户操作权限)
## 规范
> #### 2.2 SQL的基本书写规则
> 1. SQL语句要以分号（ ; ）结尾
> 2. SQL 不区分关键字的大小写，但是插入到表中的数据是区分大小写的
> 3. 

> 4. win 系统默认不区分表名及字段名的大小写
> 5. linux / mac 默认严格区分表名及字段名的大小写
> 6. **SQL 语句的单词之间需使用半角空格或换行符来进行分隔，且不能使用全角空格作为单词的分隔符，否则会发生错误，出现无法预期的结果。**
> 7. **星号（*）代表全部列的意思。**
> 8. SQL中可以随意使用换行符，不影响语句执行（但不可插入空行）。
> 9. **设定汉语别名时需要使用双引号（"）括起来。**
> 10. 在SELECT语句中使用DISTINCT可以删除重复行。
> 11. 注释是SQL语句中用来标识说明或者注意事项的部分。分为1行注释"-- "和多行注释两种"/* */"。
> 12. **希望选取NULL记录时，需要在条件表达式中使用IS NULL运算符。希望选取不是NULL的记录时，需要在条件表达式中使用IS NOT NULL运算符。**
> 13. 要表示“不是……”时，除了前文的<>运算符外，还存在另外一个表示否定、使用范围更广的运算符：NOT
> 
> where not  条件, not 不能单独使用.
> **      **

# Mysql用户
> 开源,跨平台,轻量级, 成本低
> 

:::info
**sql数据库的系统库是自己生成的, 相当于数据库的身份证, 一共有四个, 分别为:**
**1. information_schema**
**2. performance_schema**
**3. mysql**
**4. sys**

:::
```markdown
information_schema 里面有61张表,
													包括SCHEMATA   --------->里面有所有数据库的信息(SCHEMA_NAME字段显示所有的数据库名称)
                                TABLES  ----------> 存储所有表的信息(里面有 table_name 这个字段,
                                																		输入:select table_name from TABLES;
                                                                    来查看整个的数据库里面的所有的表的名称.  
                                 COLUMNS -----------> 用来存储所有列的信息 里面有column_name

performance_schema库共87张表
                  :用来收集数据服务器性能参数的, 数据直接放在内存中, 相当于磁盘

mysql库: 核心数据库
      主要存储了数据库用户的信息(比如:账号), 权限, 关键字等mysql自己需要用到的控制和管理信息;
      不可以删除;

sys库: 这和里 information_schema和performance_schema, 查询出的数据更易理解.
      	可以查询出谁是用了最多的资源, 那张表被访问最多.
```
## MySQL四种基本数据类型
**注:数据库创建的表，所有的列都必须指定数据类型，每一列都不能存储与该列数据类型不符的数据**
> 1. integer型-------->只能存储整数, 不能存储
> 2. char型-------> 当字符串的长度没有大到设定的长度的时候, mysql会自动使用半角空格进行填充(一般不用, 因为占内存)
> 3. varchar型----> 也是用来设定能填充的字符长度, 但是如果输入的内容小于设定的字符长度, 不会用半角空格填充.
> 4. date---->用来指定存储日期

## 约束字段
> **约束是对存储的数据进行一些限制, 或者追加条件**

1. not null-----> 表示该类必须要有存储数据
2. primary key---->主键约束, 代表该列是唯一值, 可以通过这一类为条件取出指定行的数据内容.
> 主键不设置可能会造成语法错误

3. default 数字 ------> 设置默认数字,  当然也可以用default 来设置其他的默认值.
## Mysql数据库的使用命令
### 进入,浏览,退出
> 1. 数据库的登录

```markdown
mysql -u root -p

  
然后输入密码
```

> 2. 查询所有的数据库

```markdown
show databases;
```

> 3. 使用数据库

```markdown
use 数据库名;
```

> 4. 使用数据库中的某个表

```markdown
show tables;
```

> 5. 退出数据库

```markdown
quit
```

```markdown
# 创建数据库
create database <数据库名>;

# 创建表名  先进入到数据库, 在创建表
create table <表名>;

# 删除表
drop table <表名>;

#
```
> **注意:删除的表是无法恢复的**


```markdown
# 给表添加列
ALTER TABLE < 表名 > ADD COLUMN < 列的定义, 怎么添加字段的,列就怎么添加 >;
例子:
ALTER TABLE product ADD COLUMN product_name_pinyin VARCHAR(100);

# 删除某一列
ALTER TABLE < 表名 > DROP COLUMN < 列名 >;

# 快速清空某张表里面的所有的内容
truncate table <表名>;
```

> **ALTER TABLE 语句和 DROP TABLE 语句一样，执行之后无法恢复**

### 数据更新--->update
```markdown
# 更新数据
update <表名>


# 一些条件命令
where 
order by 
limit
set


# 例子1: 将 product表里面的 regist_date列对应的时间都改为2009-10-10
mysql> update product
    -> set regist_date = '2009-10-10';



# 例子2: 将 sale_price列,对应的数据 都乘以10,
#         前提是 product_type对应的数据是厨房用具
mysql> update product 
    -> set sale_price = sale_price * 10
    -> where product_type = '厨房用具';



# 例子3: 将product 表里面product_Id 是0008的对应的日期改为null
mysql> update product
    -> set registe_date = null
    -> where product_id = '008';



# 例子4: 同时修改多列
# 将 product 表里面的sale_price列的所有数据都 乘以10,
#  并且将purchase_price 列对应的数据都除以2
mysql> update product
    -> set sale_price = sale_price * 10
    -> ,
    -> purchase_price = purchase_price / 2
    -> where product_type = '厨房用具';
```
```markdown
# 使用union 进行联合查询
        特点:1. 前后查询的结果互不干扰(也就是说, 即使前面没查到, 只要后面能查到, 它也会展现出结果)
            2. 前后查询的字段数量要一致. 
            错误示例:select id from test_1 where id=1 union select * from test_1 where id=2
                      错音: 因为前后查了 id 这一个字段, 后面*却查了所有的字段
                      
# 使用 order by 进行指定字段排序, 还可以猜解列数
        示例1: 按照 test_1 表里面的字段id 进行排序
        		select * from test_1 order by id;
        示例2: 按照test_1表里面的 第一个字段进行排序
            select * from test_1 order by 1;
            注意: 如果查第100个字段, 表里面没有第100个字段, 那么就和报错, 
                  这就说明了表里面的字段少于100, 也就是表的列小于100.
          

```

### 数据插入---insert
```markdown
# insert  使用格式
INSERT INTO <表名> (列1, 列2, 列3, ……) VALUES (值1, 值2, 值3, ……); 

# 例子1: 向productins表里面 的product_id, product_name,product_type
#        对应的列添加 005, 高压锅, 厨房用具      这行内容
mysql> insert into productins(
    -> product_id,product_name,product_type)
    -> value
    -> ('0005','高压锅','厨房用具')
    -> ;


# 例子2:向某一行里面的所有字段都添加对应的内容, 那么对应字段可以直接不写了,
#       直接写 value值

# 这里productins表里面有是三字段.
mysql> insert into productins
    -> values('007','高压锅','书房四宝');
# 例子3:将 product里面的某些字段内容 复制到 productcopy这张表里面.
#       注意:被查询的字段要少于
mysql> insert into productcopy(product_id,product_name,product_type,product_price,other)
    -> select product_id,product_name,product_type from product;



```
> **INSERT 语句中想给某一列**


### 数据查询--->select
```markdown
# 查询格式
select 列名 from 表名 where 条件

# as指定列的别名, 指定为中文名时, 要用双引号括起来.
select product_id as id,
       product_name as name,
       purchase_price as "进货单价"
from product;

# 查询的时候常常使用where 来进行条件约束, 具体要结合运算符
例如:
加法	+
减法	-
乘法	*
除法	/
=	和~相等
<>	和~不相等
>=	大于等于~
>	大于~
<=	小于等于~
<	小于~

# 使用not查询, 查询弹夹 不是大于等于1000的product_name.
select product_name from product where not sale_price >=1000;


# and和or同时存在的时候,想要优先以or 为查询条件就要用到括号
# 例子1: 查询 商品种类(product_type)为办公用品”并且“登记日期是 2009 年 9 月 11 日或者 2009 年 9 月 20 日”
mysql> select product_name from product where
    -> product_type = '办公用品'
    -> and(regist_date = '2009-9-10'
    -> or regist_date = '2009-09-20');






```
:::success

1. 当希望同时使用多个查询条件时，可以使用AND或者OR运算符。** AND 运算符优先于 OR 运算符，想要优先执行OR运算，可以使用括号**
2. 使用 not 查询不是^^^^的条件
3. 

:::
#### 真值
:::info
**所谓的真值就是 只为 真(True)或者为假(False)的值**

1. **AND 运算符****：**两侧的真值都为真时返回真，除此之外都返回假。
2. **OR 运算符****：**两侧的真值只要有一个不为假就返回真，只有当其两侧的真值都为假时才返回假。
3. **NOT运算符****：**只是单纯的将真转换为假，将假转换为真。
4. 真值的优先级看  要看真的成分,  越真,则优先级越高

![image.png](https://cdn.nlark.com/yuque/0/2022/png/26140423/1664756932172-77e35a9c-a903-4e3e-a2a5-269deedc69dc.png#averageHue=%23f9f8f7&clientId=u5b266dc0-09b0-4&errorMessage=unknown%20error&from=paste&height=354&id=u3e97351d&originHeight=443&originWidth=823&originalType=binary&ratio=1&rotation=0&showTitle=false&size=72384&status=error&style=none&taskId=ufa3b8e1f-969f-43c6-899f-dd2fc021b36&title=&width=658.4)

真--->不确定(意味着可能为真)----->假(意味着不可能为真)
:::
#### 聚合查询
> 用于汇总的函数叫做 聚合函数, 如下:

:::info

1. COUNT：计算表中的记录数（行数）
2. SUM：计算表中数值列中数据的合计值
3. AVG：计算表中数值列中数据的平均值
4. MAX：求出表中任意列中数据的最大值
5. MIN：求出表中任意列中数据的最小值

注意:

1. MAX/MIN函数几乎适用于所有数据类型的列。SUM/AVG函数只适用于数值类型的列。
2. **COUNT(*)会得到包含NULL的数据行数，而COUNT(<列名>)会得到NULL之外的数据行数。**
:::
```markdown
# 统计 product表中 product_type 非空的函数.
 select count(product_type) from product;

# 统计 product表中 sale_price 和 purchase_price的平均值.
#select avg(sale_price),avg(purchase_price) from product;

# 其他聚合函数用法类似.

# 计算去除重复项以后的数据行数 结合distinct
# 例子: 统计去除product表里面的 product_type的重复项的prod_type行数
select count(distinct product_type) from product;



```

#### 分组---->group by
```markdown
# 基本格式:
SELECT <列名1>,<列名2>, <列名3>, ……
  FROM <表名>
 GROUP BY <列名1>, <列名2>, <列名3>, ……;

 # 例子: 查询按照 product_type来查询 group_type的行数
 select group_type,count(*) from product group by product_type
```
#### having---->对分组后的数据进行过滤
```markdown
# 当分组完成以后, 选出其中的两组, 这个时候就要用到having
select product_type,count(*) from product 
group by product_type
having count(*) = 2;
```
> 1. GROUP BY的子句书写顺序有严格要求，不按要求会导致SQL无法正常执行，目前出现过的子句**书写****顺序**为：
> 
**1****.****SELECT → 2. FROM → 3. WHERE → 4. 		         GROUP BY**
> 2. **在聚合函数的SELECT子句中写了聚合健以外的列 使用COUNT等聚合函数时，SELECT子句中如果出现列名，只能是GROUP BY子句中指定的列名（也就是聚合键）。**
> 3. **在GROUP BY子句中使用列的别名 SELECT子句中可以通过AS来指定别名，但在GROUP BY中不能使用别名。因为在DBMS中 ,SELECT子句在GROUP BY子句后执行。**
> 4. **在WHERE中使用聚合函数 原因是聚合函数的使用前提是结果集已经确定，而WHERE还处于确定结果集的过程中，所以相互矛盾会引发错误。 如果想指定条件，可以在SELECT，HAVING以及ORDER BY子句中使用聚合函数。**
> 5. **在 GROUP BY 子句中指定的列称为聚合键或者分组列。**
> 6. **WHERE子句只能指定记录（行）的条件，而不能用来指定组的条件**
> 




#### 排序--->order by
> 1. **SQL中的执行结果是随机排列的，当需要按照特定顺序排序时，可已使用ORDER BY子句。**
> 2. **排序默认是升序, 如果要降序默认使用desc**
> 3. **当用于排序的列名中含有NULL时，NULL会在开头或末尾进行汇总。**

```markdown
# 例子1: 根据sale_price 来进行降序排序.
select product_type,product_name from product
order by sale price desc;

# 例子2: 排序可以按照多个键进行排序
select product_name,product_price,product_id form product
order by product_product,product_id

# 例子3:
# 请编写一条SELECT语句，求出销售单价（sale_price列）合计值大于进货单价（purchase_price列）合计值1.5倍的商品种类
 select product_type,sum(sale_price),sum(purchase_price) from product product 
    -> group by product_type
    -> having sum(sale_price) > sum(purchase_price)*1.5;

```

> **在having中语句执行顺序:**
> **FROM → WHERE → GROUP BY → HAVING → SELECT → ORDER BY**
> 所以**在ORDER BY中可以使用别名，但是在GROUP BY中不能使用别名.**
> 


### 数据查询之复杂查询方法(视图,子查询,函数等)
#### 视图
:::info

1. 视图是一个虚拟的表,视图是依据SELECT语句来创建的, 所以操作视图时会根据创建视图的SELECT语句生成一张虚拟表，然后**在这张虚拟表上做SQL操作。**




2. **视图是基于真实表的一张虚拟的表，其数据来源均建立在真实表的基础上。将视图看做一扇窗户, 通过这扇窗户我们可以看到真是数据表里面的真是的数据.**




3. **虽然有了真是的数据表, 为啥还用视图呢?**
         1. **通过视图来频繁使用select语句来进行保存,提高效率**
         2. **sql数据表展示的数据不是很好看, 通过视图可以使用户看到的数据更加清晰**
         3. **驶入可以不对外公开全部字段, 增加家数据的保密性**
         4. **降低数据的冗余**



:::

##### 视图的创建, 查询,修改,更新,删除

```markdown
# 创建视图的格式
CREATE VIEW <视图名称>(<列名1>,<列名2>,...) AS <SELECT语句>

# 例子1: 基于 product 和 shop_product两张表, 串讲视图 view_shop
#        条件是product表里的 product_id 等于 shop_product表里面的 product_id.
CREATE VIEW view_shop_product(product_type, sale_price, shop_name)
AS
SELECT product_type, sale_price, shop_name
  FROM product,
       shop_product
 WHERE product.product_id = shop_product.product_id;



 # 视图的查询和表的查询是一样的语句, 就把视图当成真实的数据表进行查询.



# 修改视图  格式:
ALTER VIEW <视图名> AS <SELECT语句>
# 修改视图也就是修改了视图要执行的查询语句
# 例子:
alter view productsum as
select product_type,sale_price from product
where regist_date > '2009-09-11';




# 更新视图
使用的语句和更新表是一样的, 我么就把视图当成真实的表去更新
update 视图名 set 要设置的条件 where 条件.

注意: 当我们更新视图的时候,在真实的表中能通过视图别看到的数据也会被更新,
      而真实的表中, 不能通过视图看到的数据任然不变.



# 删除视图
drop view 视图名;

```
![图片来源于阿里云龙珠计划sql训练营](https://cdn.nlark.com/yuque/0/2022/png/26140423/1664763171666-8e9af017-bae2-4531-af2b-87e99a91393e.png#averageHue=%23fcfafa&clientId=u5b266dc0-09b0-4&errorMessage=unknown%20error&from=paste&height=611&id=u3ede1e69&originHeight=764&originWidth=956&originalType=binary&ratio=1&rotation=0&showTitle=true&size=143468&status=error&style=none&taskId=ua2cb06d8-051a-4928-95e6-1cf90359159&title=%E5%9B%BE%E7%89%87%E6%9D%A5%E6%BA%90%E4%BA%8E%E9%98%BF%E9%87%8C%E4%BA%91%E9%BE%99%E7%8F%A0%E8%AE%A1%E5%88%92sql%E8%AE%AD%E7%BB%83%E8%90%A5&width=764.8 "图片来源于阿里云龙珠计划sql训练营")
##### 注意点
> 1. **我们也能尽量避免在视图的基础上创建视图, 因为那会降低SQL性能**
> 


> 2. **一般的DBMS中定义视图时不能使用ORDER BY语句,因为视图和表一样都是没有顺序的**
> 
_**在 MySQL中视图的定义是允许使用 ORDER BY 语句的，但是若从特定视图进行选择，而该视图使用了自己的 ORDER BY 语句，则视图定义中的 ORDER BY 将被忽略
> 

> 3. **视图名在数据库中需要是唯一的, 不能有重名的视图**
> 4. **SELECT 语句中列的排列顺序和视图中列的排列顺序相同， SELECT 语句中的第 1 列就是视图中的第 1 列，SELECT 语句中的第 2 列就是视图中的第 2 列，以此类推**
> 

**5. 对于一个视图来说，如果包含以下结构的任意一种都是不可以被更新的：**
> - **聚合函数 SUM()、MIN()、MAX()、COUNT() 等。**
> - **DISTINCT 关键字。**
> - **GROUP BY 子句。**
> - **HAVING 子句。**
> - **UNION 或 UNION ALL 运算符。**
> - **FROM 子句中包含多个表。**
> 


#### 子查询

1. 

> 什么是子查询:
> **子查询指一个查询语句嵌套在另一个查询语句内部的查询，这个特性从 MySQL 4.1 开始引入，在 SELECT 子句中先计算子查询，子查询结果作为外层另一个查询的过滤条件，查询可以基于一个表或者多个表。**
> 

> **分为: 嵌套子查询, 标量子查询,关联子查询, **
> 

**2. 子查询先执行里面的在执行外面的**

**3. 子查询是一次性的，所以子查询不会像视图那样保存在存储介质中， 而是在 SELECT 语句执行之后就消失了。**

##### 嵌套子查询
> 1. ** 尽量避免使用嵌套子查询, 因为随着嵌套次数的增多, sql语句会越来越那一理解.**
> 2. **嵌套的时候先执行里面的后执行外面的.**


##### 标量子查询
> 标量就是单一的意思，单一就是要求我们执行的SQL语句只能返回一个值，也就是要返回表中具体的**某一行的某一列**

```markdown
# 例子1:
mysql> select product_id,product_name,sale_price,
    -> (select avg(sale_price) from product)
    -> as avg_price
    -> from product
```

##### 关联查询
> 执行逻辑:
> 1. 首先执行不带WHERE的主查询
> 2. 根据主查询讯结果匹配product_type，获取子查询结果
> 3. 将子查询结果再与主查询结合执行完整的SQL语句
> 
[https://zhuanlan.zhihu.com/p/41844742?spm=5176.21852664.0.0.7b2f11b7RYrtWS](https://zhuanlan.zhihu.com/p/41844742?spm=5176.21852664.0.0.7b2f11b7RYrtWS)
> 简记执行顺序:FWGHSO

**很重要的例子:**
![image.png](https://cdn.nlark.com/yuque/0/2022/png/26140423/1664778996811-e11a4203-3212-4fcb-8b22-b47081198640.png#averageHue=%23848280&clientId=u5b266dc0-09b0-4&errorMessage=unknown%20error&from=paste&height=354&id=u9dec0bbe&originHeight=443&originWidth=876&originalType=binary&ratio=1&rotation=0&showTitle=false&size=47686&status=error&style=none&taskId=u4633b685-aeea-4d0b-b5bc-90baf8026d4&title=&width=700.8)
```markdown
# 例子:
-- 创建视图的语句
CREATE VIEW AvgPriceByType AS
SELECT product_id,
 product_name,
 product_type,
 sale_price,
 (SELECT AVG(sale_price)
 FROM product p2
 WHERE p1.product_type = p2.product_type
 GROUP BY p1.product_type) AS avg_sale_price
FROM product p1;
-- 确认视图内容
SELECT * FROM AvgPriceByType;
```


#### 各种函数
> sql自带许多的函数,具体分为以下几类:
> - 算术函数 （用来进行数值计算的函数）
> - 字符串函数 （用来进行字符串操作的函数）
> - 日期函数 （用来进行日期操作的函数）
> - 转换函数 （用来转换数据类型和值的函数）
> - 聚合函数 （用来进行数据聚合的函数）

```markdown
# 绝对值
ABS( 数值 )

# 求余数, SQL Server 不支持该函数，其使用%符号来计算余数。
mod(被除数,除数)

# 字符串函数

# concat()用来拼接
concat(str1,str2,str3)

# 字符长度
length(字符长)

# lower 将英文转换成小写, upper讲英文转换成大写.

# REPLACE( 对象字符串，替换前的字符串，替换后的字符串 )

# substring 字符串的截取
SUBSTRING （对象字符串 FROM 截取的起始位置 FOR 截取的字符数）

# substring_index   
SUBSTRING_INDEX (原始字符串， 分隔符，n)

# 日期函数
# 获取当前日期
mysql> select current_date;
+--------------+
| current_date |
+--------------+
| 2022-10-03   |
+--------------+

# 获取当前时间
mysql> select current_time;
+--------------+
| current_time |
+--------------+
| 15:01:11     |
+--------------+

# 获取当前日期和时间
mysql> select current_timestamp;
+---------------------+
| current_timestamp   |
+---------------------+
| 2022-10-03 15:02:08 |
+---------------------+
1 row in set (0.00 sec)

# 获取当前日期也可以使用 sysdate() 函数.

# 截取取年月日,小时,分钟,秒 ------> 最后获得的是 数值类型
SELECT CURRENT_TIMESTAMP as now,
EXTRACT(YEAR   FROM CURRENT_TIMESTAMP) AS year,
EXTRACT(MONTH  FROM CURRENT_TIMESTAMP) AS month,
EXTRACT(DAY    FROM CURRENT_TIMESTAMP) AS day,
EXTRACT(HOUR   FROM CURRENT_TIMESTAMP) AS hour,
EXTRACT(MINUTE FROM CURRENT_TIMESTAMP) AS MINute,
EXTRACT(SECOND FROM CURRENT_TIMESTAMP) AS second;
+---------------------+------+-------+------+------+--------+--------+
| now                 | year | month | day  | hour | MINute | second |
+---------------------+------+-------+------+------+--------+--------+
| 2020-08-08 17:34:38 | 2020 |     8 |    8 |   17 |     34 |     38 |




# 转化函数 CAST（转换前的值 AS 想要转换的数据类型）
cast 转化数据的类型
# 例如: 将字符 '001' 转化成有符号数字类型.
select cast ('0001',signed integer) as in_col;

mysql> select cast('0001' as signed integer) as my_t;
+------+
| my_t |
+------+
|    1 |
+------+

#
COALESCE 是 SQL 有的函数。该函数会返回可变参数 A 中左侧开始第 1个不是NULL的值。参数个数是可变的，因此可以根据需要无限增加。

在 SQL 语句中将 NULL 转换为其他值时就会用到转换函数。

SELECT COALESCE(NULL, 11) AS col_1,
COALESCE(NULL, 'hello world', NULL) AS col_2,
COALESCE(NULL, NULL, '2020-11-01') AS col_3;
+-------+-------------+------------+
| col_1 | col_2       | col_3      |
+-------+-------------+------------+
|    11 | hello world | 2020-11-01 |
+-------+-------------+------------+
1 row in set (0.00 sec),^^^)

mysql> select coalesce(11,22) as col_1;
+-------+
| col_1 |
+-------+
|    11 |
因为上面 11就是非空的, 所以返回了11, 22就不管了.




```
![来源天池龙珠计划](https://cdn.nlark.com/yuque/0/2022/png/26140423/1664780300173-2b3c036c-3c27-4afc-acf2-8774aee311a8.png#averageHue=%236a6a69&clientId=u5b266dc0-09b0-4&errorMessage=unknown%20error&from=paste&height=390&id=ue97c4268&originHeight=488&originWidth=880&originalType=binary&ratio=1&rotation=0&showTitle=true&size=34158&status=error&style=none&taskId=u715ab1f9-cd5c-4d1a-ba08-02368df696d&title=%E6%9D%A5%E6%BA%90%E5%A4%A9%E6%B1%A0%E9%BE%99%E7%8F%A0%E8%AE%A1%E5%88%92&width=704 "来源天池龙珠计划")
#### 谓词
> 谓词就是返回值为真值的函数。包括**TRUE / FALSE / UNKNOWN**。

> 谓词有一下几个:
> like
> between
> is null 
> is not null
> in
> not in 
> or
> exists                  --可以用来替换 in
> not exist            --可以用来替换 not in 


##### like(模糊查询)
```markdown
# 查询出 samplelike表中  以 ddd 开头的strcol列中的字段, 展现出表
select * from samplelike where strcol like 'ddd%';

# % 表示一个或者多个字符, 因为这里不知道ddd开头, ddd后面有几个字符, 所以就用了%

# 同理: 用 % 和like 查询出 中间含有 ddd 的字符 , 只要含有 ddd就行, 不管前面后面有几个字符, 就算0个也行.
SELECT * 
FROM samplelike WHERE strcol LIKE '%ddd%';
+--------+
| strcol |
+--------+
| dddabc |
+--------+

# 下划线 _ 表示任意一个字符 , 和 % 差不多
# 只不过 一个下划线代表一个任意的字符, 两个代表 2个任意字符, n个代表n个.



```

##### between(范围查询)
使用between会包含临界值
```markdown
# 查询出在100 和 1000, 包括100和1000的sale_price.
select sale_price from product
where sale_price between 100 and 1000;

```


##### is null
> 选出 某个字段的值为 null  
> 注意: 要选出 值为 null 的数据, 不能用 =  号, 作为条件, 必须用 is null.

```markdown
select product_name from product where purchase_price is null;
```

> is not null 用法类似.


##### or ,in  简单示例
```markdown
select product_name ,purchase_price from product where purchase_price = 320
or purchase_price = 500
or purchase_price = 5000;


查询结果为:
+--------------+----------------+
| product_name | purchase_price |
+--------------+----------------+
| T恤          |            500 |
| 打孔器       |            320 |
| 高压锅       |           5000 |


# 使用 in 更加简洁.
SELECT product_name, purchase_price
FROM product
WHERE purchase_price IN (320, 500, 5000);
```

> **当一个字段作为主键并不能唯一确定唯一的一行数据的时候, 就可以使用两个甚至多个作为 primary key  来唯一确定数据.**


> **in 可以和 子查询联用  (not in 也可以)**

```markdown
# 此处知识为了 认识一下形式哈, 不作过多解释.
SELECT product_name, sale_price
FROM product
WHERE product_id IN (SELECT product_id
  FROM shopproduct
                       WHERE shop_id = '000C');
```

:::info
**个门店的在售商品可能有成百上千个，手工维护在售商品编号真是个大工程。使用子查询即可保持 sql 语句不变，极大提高了程序的可维护性，这是系统开发中需要重点考虑的内容。**
:::

##### exist
> 作用:**判断是否存在满足某种条件的记录”**。
> 如果存在这样的记录就返回真（TRUE），如果不存在就返回假（FALSE）。


> exist  是只有 1 个参数的谓词。 所以，EXIST 只需要在右侧书写 1 个参数，该参数通常都会是一个子查询。

```markdown
# 例子:
select product_name, sale_price from product as p
where exists (
select * from shopproduct as sp where
sp.shop_id = '00C'
and sp.product_id = p.product_id);
```

:::info
**not exist 和exist用法类似, 只不过NOT EXIST 与 EXIST 相反，当“不存在”满足子查询中指定条件的记录时返回真（TRUE）。**
:::



### CASE表达式
> 1. 用于区分情况.
> 2. 用于 **行转列, 列转行**
> 

> 分为:
> 1. 简单 CASE表达式
> 2. 搜索CASE表达式( 包括了简单的功能)

```markdown
# 使用格式:
CASE WHEN <求值表达式> THEN <表达式>
     WHEN <求值表达式> THEN <表达式>
     WHEN <求值表达式> THEN <表达式>
     .
     .
     .
ELSE <表达式>
END

# 例子1:
mysql> select product_name,
    -> case when product_type = '衣服' then concat('A:',product_type)
    -> when product_type = '办公用品' then concat('B:',product_type)
    -> else null
    -> end as ab_product_type
    -> from product



# 例子2:
将下面这种形式的表,
+--------------+-----------+
| product_type | sum_price |
+--------------+-----------+
| 衣服         |      5000 |
| 办公用品      |       600 |
| 厨房用具      |     11180 |
+--------------+-----------+

转成这种形式的表
+-------------------+-------------------+------------------+
| sum_price_clothes | sum_price_kitchen | sum_price_office |
+-------------------+-------------------+------------------+
|              5000 |             11180 |              600 |
+-------------------+-------------------+------------------+

只需要:  聚合函数+case when 表达式
命令如下:
SELECT SUM(CASE WHEN product_type = '衣服' THEN sale_price ELSE 0 END) AS sum_price_clothes,
       SUM(CASE WHEN product_type = '厨房用具' THEN sale_price ELSE 0 END) AS sum_price_kitchen,
       SUM(CASE WHEN product_type = '办公用品' THEN sale_price ELSE 0 END) AS sum_price_office
  FROM product;


# 例子3:
SELECT name,
       MAX(CASE WHEN subject = '语文' THEN subject ELSE null END) as chinese,
       MAX(CASE WHEN subject = '数学' THEN subject ELSE null END) as math,
       MIN(CASE WHEN subject = '外语' THEN subject ELSE null END) as english
  FROM score
 GROUP BY name;
+------+---------+------+---------+
| name | chinese | math | english |
+------+---------+------+---------+
| 张三 | 语文    | 数学 | 外语    |
| 李四 | 语文    | 数学 | 外语    |
+------+---------+------+---------+


# 例子4:
按照销售单价（ sale_price）对 product（商品）表中的商品进行如下分类。

低档商品：销售单价在1000日元以下（T恤衫、办公用品、叉子、擦菜板、 圆珠笔）
中档商品：销售单价在1001日元以上3000日元以下（菜刀）
高档商品：销售单价在3001日元以上（运动T恤、高压锅）
请编写出统计上述商品种类中所包含的商品数量的 SELECT 语句，结果如下所示。

执行结果

low_price | mid_price | high_price
----------+-----------+------------
        5 |         1 |         2


解:
SELECT SUM(CASE WHEN sale_price <= 1000 THEN 1 ELSE 0 END) AS
low_price,
 SUM(CASE WHEN sale_price BETWEEN 1001 AND 3000 THEN 1 ELSE 0 END) AS
mid_price,
 SUM(CASE WHEN sale_price >= 3001 THEN 1 ELSE 0 END) AS
high_price
 FROM product;
				
# 上述语句执行时，依次判断 when 表达式是否为真值，是则执行 THEN 后的语句，
# 如果所有的 when 表达式均为假，则执行 ELSE 后的语句。
# 无论多么庞大的 CASE 表达式，最后也只会返回一个值。
```
:::info
**总结：**

1. **当待转换列为数字时，可以使用SUM AVG MAX MIN等聚合函数；**
2. **当待转换列为文本时，可以使用MAX MIN等聚合函数**
:::


### 注意点:
> 1. 运算或者函数中含有 NULL 时，结果全都会变为NULL

> 2.  NOT IN 的参数中不能包含 NULL ，否则，查询结果通常为空。  

> 3.  谓词⽆法与 NULL 进⾏⽐较  , 使用的时候也就无法取出null.


## 集合
### union (并集)
> SQL 语句的 UNION 会对两个查询的结果集进行合并和去重, 这种去重不仅会去掉两个结果集相互重复的, 还会去掉一个结果集中的重复行

```markdown
# 将 数据库中的一张表当做一个集合
# 使用union可以取得查询的 并集 结果
# 注意: 如果要对同一张表的查询结果取并集也可以使用 where + or  , 但是如果是对不同的表取并集, 那就得用 union了
select product_id,product_name from product
union
select product_id, product_name from product2;

# 查询到的结果是 product  和 product2这两张表都有的内容

# 对于查询结果未知 我们可以使用 null
```

**对于查询结果未知 我们可以使用 null**

**union 隐式查询**
> **对于 union 查询到的结果,  我们也可以将数据类型不同的结果进行查询, 这就是 也能是-------> 隐式类型转换.**
> ![image.png](https://cdn.nlark.com/yuque/0/2022/png/26140423/1664889604907-039deac5-7eca-4e7e-b4d8-0aad11998e80.png#averageHue=%23d4cab6&clientId=uf227dee2-2961-4&errorMessage=unknown%20error&from=paste&height=429&id=ub9959de5&originHeight=536&originWidth=745&originalType=binary&ratio=1&rotation=0&showTitle=false&size=64720&status=error&style=none&taskId=u36a07dbd-8694-4569-ad17-f678b795d11&title=&width=596)
> 日期类型和字符串,数值以及缺失值均能兼容.



### union all
> 使用 union all 可以保留, 查询结果中重复的行

![本图来自网络](https://cdn.nlark.com/yuque/0/2022/png/26140423/1664888660231-e9f93724-d71b-4fc5-9ed0-390f5678fb7d.png#averageHue=%23e4e1e0&clientId=uf227dee2-2961-4&errorMessage=unknown%20error&from=paste&height=257&id=u16cd3aaa&originHeight=321&originWidth=668&originalType=binary&ratio=1&rotation=0&showTitle=true&size=46449&status=error&style=none&taskId=u04a9cb62-3574-4a27-9099-3b4fbd9ca74&title=%E6%9C%AC%E5%9B%BE%E6%9D%A5%E8%87%AA%E7%BD%91%E7%BB%9C&width=534.4 "本图来自网络")

#### 集合中的--交
> 集合中的交可以通过and 来进行实现.


#### 集合的差

#### 对称差
```markdown
# 现在有集合A 和 集合B
# 对称差等于 A-B并上B-A   
# 例如 使用 not in 和 union 就可以实现
```





### bag模型 和 set 模型
bag模式的----并
> ![本图片来自: 阿里云](https://cdn.nlark.com/yuque/0/2022/png/26140423/1664889186865-57b62fd1-ab99-4920-803a-1a82c32c4017.png#averageHue=%23fdfbf8&clientId=uf227dee2-2961-4&errorMessage=unknown%20error&from=paste&height=198&id=uf8c02ba0&originHeight=247&originWidth=885&originalType=binary&ratio=1&rotation=0&showTitle=true&size=47897&status=error&style=none&taskId=u8499571a-930b-4f03-8f19-5361726bf21&title=%E6%9C%AC%E5%9B%BE%E7%89%87%E6%9D%A5%E8%87%AA%3A%20%E9%98%BF%E9%87%8C%E4%BA%91&width=708 "本图片来自: 阿里云")

bag模式的---交
> 对于两个 bag, 他们的交运算会按照: **1.该元素是否同时属于两个 bag, 2.该元素在两个 bag 中的最小出现次数**这两个方面来进行计算. 因此对于 A = {1,1,1,2,3,5,7}, B = {1,1,2,2,4,6,8} 两个 bag, 它们的交运算结果就等于 {1,1,2}.


bag模式的---差
> 只有属于被减数的bag的元素才参与EXCEP ALL运算, 并且差bag中的次数,等于该元素在两个bag的出现次数之差(差为零或负数则不出现). 因此对于 A = {1,1,1,2,3,5,7}, B = {1,1,2,2,4,6,8} 两个 bag, 针对于A, 它们的差就等于 {1,3,5,7}.



## 连结(join)
> 掌握了连结, 能够从两张甚至多张表中获取列, 能够将过去使用关联子查询等过于复杂的查询简化为更加易读的形式, 以及进行一些更加复杂的查询.

> 其实可以想象一下, 显示中我们用胶带将两张纸粘在一起, 那么在SQL中这个胶带就是 两张表**共有的**字段.  通过**共有的**字段将不同的表连在一起.


#### 内连结
```markdown
# 语法形式
FROM <tb_1> INNER JOIN <tb_2> ON <condition(s)>

# 例子:  注意执行的逻辑顺序. 
SELECT SP.shop_id
       ,SP.shop_name
       ,SP.product_id
       ,P.product_name
       ,P.product_type
       ,P.sale_price
       ,SP.quantity
  FROMshopproduct AS SP
 INNER JOIN product AS P
    ON SP.product_id = P.product_id;
 WHERE shop_name = '东京'
   AND product_type = '衣服' ;


 # 也可以将 where 的条件给 on 但是此时要用括号括起来

 上方代码后面部分的改写: (不常用, 因为条件多下去就不容易阅读了)
 INNER JOINproduct AS P
    ON (SP.product_id = P.product_id
   AND SP.shop_name = '东京'
   AND P.product_type = '衣服') ;

# 如果使用 group by 进行分组查询,那么执行顺序是:
  先将两个表连结起来  ,  再去 分组.

# 例子2: 内连结中使用子查询
SELECT SP.shop_id
       ,SP.shop_name
       ,SP.product_id
       ,P.product_name
       ,P.product_type
       ,P.sale_price
       ,SP.quantity
  FROM (-- 子查询 1:从shopproduct 表筛选出东京商店的信息
        SELECT *
          FROMshopproduct
         WHERE shop_name = '东京' ) AS SP
 INNER JOIN -- 子查询 2:从 product 表筛选出衣服类商品的信息
   (SELECT *
      FROMproduct
     WHERE product_type = '衣服') AS P
    ON SP.product_id = P.product_id;
```

> 自连结(self join )指的是一张表与自身连结,  自连结并不独立与内连结和外连接, 它既可以是外连接也可以是内连结 , 它是不同于内连结外连接的连接分类方法.



##### 内连结注意点
:::info

1. 内连结必须使用 on 来进行连结
2. 对使用的select 语句 最好按照   表名.列名   的格式来进行使用, 这样写是为了方便以后的查看 和 反之报错.
3. **如果需要在使用内连结的时候同时使用 WHERE 子句对检索结果进行筛选, 则需要把 WHERE 子句写在 ON 子句的后边.**

最终的结果是 在把两张表连结的基础上, 再去执行where中规定的条件.
也可以将 where 的条件给 on 但是此时要用括号括起来

:::

自然连接(natural join)
> 自然连结 是内连结的一种特例,  只不过按照两个表中都包含的列名来进行等值内连结, 此时**无需使用 ON 来指定连接条件.**

```markdown
# 格式
SELECT *  FROM shopproduct NATURAL JOIN product
```
> 注意:
> **两个缺失值用等号进行比较, 结果不为真. 而连结只会返回对连结条件返回为真的那些行.**



### 外连结(outer join)

1. **内连结会丢弃两张表中不满足 ON 条件的行,和内连结相对的就是外连结. **
2. 外连结会根据外连结的种类有选择地保留无法匹配到的行.
:::info
外连结的三种形式:

1. 左连结
2. 右链接
3. 全连结

**左连结会保存左表中无法按照 ON 子句匹配到的行, 此时对应右表的行均为缺失值; **
右连结则会保存右表中无法按照 ON 子句匹配到的行, 此时对应左表的行均为缺失值; 
**全外连结则会同时保存两个表中无法按照 ON子句匹配到的行, 相应的另一张表中的行用缺失值填充.**
:::

```markdown
# 左连结
SELECT SP.shop_id
       ,SP.shop_name
       ,SP.product_id
       ,P.product_name
       ,P.sale_price
  FROMproduct AS P
  LEFT OUTER JOINshopproduct AS SP
    ON SP.product_id = P.product_id;


```
#### 外连结注意点
```markdown
1. # 选取出单张表中全部的信息
2. #使用 LEFT、RIGHT 来指定主表.
   使用 LEFT 时 FROM 子句中写在左侧的表是主表,
   使用 RIGHT 时右侧的表是主表

3.
```

:::info
** MySQL8.0 目前还不支持全外连结, 不过我们可以对左连结和右连结的结果进行 UNION 来实现全外连结**。
:::


```markdown
# 例子: 就是多个 innner join 联用
SELECT SP.shop_id
       ,SP.shop_name
       ,SP.product_id
       ,P.product_name
       ,P.sale_price
       ,IP.inventory_quantity
  FROMshopproduct AS SP
 INNER JOINproduct AS P
    ON SP.product_id = P.product_id
 INNER JOIN Inventoryproduct AS IP
    ON SP.product_id = IP.product_id
 WHERE IP.inventory_id = 'P001';
```

非等值连结
> 用相等判断的等值连结, 也可以使用比较运算符来进行连接. 实际上, 包括比较运算符(<,<=,>,>=, BETWEEN)和谓词运算(LIKE, IN, NOT 等等)在内的所有的逻辑运算都可以放在 ON 子句内作为连结条件.


> **交叉连结(cross join)**
> 就是 连结不适用on.

```markdown
# 例子:
-- 1.使用关键字 CROSS JOIN 显式地进行交叉连结
SELECT SP.shop_id
       ,SP.shop_name
       ,SP.product_id
       ,P.product_name
       ,P.sale_price
  FROMshopproduct AS SP
 CROSS JOINproduct AS P;
```

## 窗口函数
> 窗口函数也称为**OLAP函数**。OLAP 是OnLine AnalyticalProcessing 的简称，意思是对数据库数据进行实时分析处理。

```markdown
# 窗口函数的书写形式：
<窗口函数> OVER ([PARTITION BY <列名>]
                     ORDER BY <排序用列名>)


# 这里的partition by 类似于分组, 但是它不会改变原来表中的行数,是多少行就是多少行.
```


 


