## 进入MongoDB
1. 我用的是宝塔界面的云服务器, 所以我可以**直接通过服务器的软件商店下载MongoDB**
2. 将pycharm连接到远程服务器上, 然后输入:

 mongo
回车, 就进入了.
**注意找一下, mongodb的端口号**
```
connecting to: mongodb://127.0.0.1: 端口号 /?compressors=disabled&gssapiServiceName=mongodb
```
##MongoDB库, 集合, 文档的操作
## 库 ---(命令)
```
# 查找所有的数据库
 show dbs  
 
 # 创建库  和  进入库, 也就是说如果这个MongoDB的库存在就是用这个库, 如果库不存在就新创建库并且进入.
 use 库名  
 
 注意: 如果创建的库里面没有数据, 人们是查不到的, 那是一个虚拟的库
 
 # db
 查看当前用的是哪一个库
 
 # 删除库, 注意一定要先进入那个要删除的库, 才能删除.
 db.dropDatabase()
```
## 集合(命令)
```
# 创建集合
 db.createCollection('集合名字')
 
 # 查找所有的集合
 show collections
 
 #删除
 db.集合名.drop()
```
## 文档(命令)
```
# 添加单条信息, 它会自动添加_id 
 db.集合名.insert({键:值})
 例子:
 db.集合.insert({'name':'小明', 'age':'18'})
 
 # 如果想要命名_id, 给_id一个value就行就行, 这里个了1 
 例子:
 db.test.insert({'_id':'1','profession':'student'})
 
 #添加多条数据
 db.集合名.insert([{文档},{文档},{文档}^^^^^^^^^^^])
 
 
 #查找数据
 db.集合.find()                 # 直接将数据展示出来.
 db.集合.find().pretty()       #这叫 美观查询, 数据将以 json格式输出.
 db.集合.find({'键':'值'})      # 凡是包含 '键':'值' 的数据, 都会把整条数据拿出来.
 
 
 #修改数据---------->下面的两种方法只会修改查到的第一条数据.
 # 下面这种方法修改后, 原来那一整条数据,只会保留修改后的这一小段,其他的全部都会删除掉.
 db.集合名.update({'原来的key':'原来的value'},{'修改后的key':'修改后value'})
 
 # 下面这种方法删除后, 只会修改要修改的内容, 其他部分的数据不动
 db.集合名.update({'原来的key':'原来的value'},{$set:{'修改后的key':'修改后的value'}})
 
 
 
 # 删除数据
 #删除所有符合条件的数据
 db.集合名.remove({'key':'value'})
 
 # 删除符合条件的第一条数据
 db.集合名.remove({'key':'value'},{justOne:true})
 
 #删除集合中所有的数据
 db.集合名.remove({})
 
 
 
 #符号
 $gte 大于等于   
 $gt   大于
 $lte  小于等于
 $lt   小于
 $and  两边必须同时满足
 $or   两面满足一个即可
 
 
 例如:  查找age是18, sex是man的数据.
  db.test.find({$and:[{'age':'18'},{'sex':'man'}]})
 
 例如: 查找age为18并且sex是man 或者  age是19并且 sex是man的数据.
 db.test.find({$or:[
         {$and:[{'age':'18'},{'sex':'man'}]},
         {$and:[{'age':'19'},{'sex':'man'}]}
 ]})
```
注意: 用直接在shell工具中用代码来操作数据库的时候, 可以现在 上方的pycharm中写好, 然后再直接复制到shell里面, 但是要注意**不要有多余的空行, 否则会报错**
# Python解释器连接MongoDB

1. 点击左上角File, ------->settings
2. 找到项目的解释器--------python interperter, 点击在右侧的输入框旁边的**齿轮**---------->Add. 
3. 在左边选择SSh interpreter, 之后填入**Host(IP)**, **UserName**, 点击下方**Next**
4. 输入密码
5. **interpreter就是配置的远程解释器**----------> 就一直一层层的找, 找到**python版本Sync folders就是要放在服务器的那个地方**, 只需要选择**Remote Path, 只要能找到就行.**

经过以上操作, pycharm里的所有的文件都搬到了云服务器上
在pycharm中操作 MongoDB
```
# 导入库
 import pymongo
 
 # 建立连接
 
 client = pymongo.MongoClient('127.0.0.1', 27017)   # 不写()里面的也行, 因为底层已经写了
 
 # 连接数据库
 db =client('MongoDB里面的数据库')
 
 # 指定集合
 collection = db['集合名']
```
之后就直接使用就可以了
例如:
```
# 添加数据, 在pycharm中, 会自己显示添加数据的方法.
 collection.insert_one({'name':'wang','age':'19'})
```
**输入完成后, 点击 Tools里面的, Deploment里面的 Upload to Default Server**
然后**运行**, 这样就直接添加进去了.
注: 

1. 添加完数据后,就将我们输入的代码注释掉, 否则, 下次运行的时候又会再次添加一段同样的数据.
2. MongoDB里面的原来的命令, 可能因为版本问题在进入pycharm后, 操作命令稍有不同, 但是整体是差不多的.
3. 使用**查询**的时候, find出来的是一个对象, 所以, 直接for循环, 遍历出来进行了.


 


