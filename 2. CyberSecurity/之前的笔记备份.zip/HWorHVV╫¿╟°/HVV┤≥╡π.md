# 护网介绍

# 常规打点思路

1. 信息收集
2. 绕开CDN找到所有靶标的真实ip
3. 找到所有目标真实的C段
4. 对所有的C段进行基础服务器的探测, 端口的扫描, 识别
5. 对所有的子域名进行手机
6. 对所有子域名的基础服务, 端口等, 进行识别和探测
7. 对所有的web服务站点进行指纹探测
8. 找到web管理的后台
9. git上找目标的各类泄露的信息, 账号密码, 敏感文件(运气好会找到泄露的云 key)

9. 从 **网盘, 百度文库, 找敏感文件, 账号密码**
10. 找设备, CMS OA的默认账号密码
11. 对web目标进行目录扫描(开代理)
12. **对.svn     .git **的项目进行源码的还原
13. 对网站前端进行源码探测收集敏感信息\
14. 对于学校:  收集学号 , 员工号 , 目标邮箱==========**> 生成社工字典**
15. 对一些企业, 技术文档wiki 尝试 查找测试账号
16. 对目标公众号, 小程序 进行流量手机

17. 想办法混入目标的QQ, 微信群等(群内部可能有文件)
18. 识别目标有用的waf(不同的waf有不同的bypass)



# 漏洞利用

1. 后台弱口令, 命令执行 , 代码执行, 反序列化, 文件上传, SQL 注入, SSRF, 敏感信息泄露, 近源



# 攻击目标的分类

##  护网重灾区

1. 学校(学生)
2. 医院(老幼)
3. 非互联网
4. 非金融的制造业



## 护网中的硬茬

> 这些都是 双倍, 设置6倍

金融,  保险公司, 电力 , 烟草,  大数据中心

**对于硬茬公司的攻击思路:**

1. 0day

2. 供应链攻击

   > 供应链公司一般和目标公司内网相连, 且在白名单里面的

   > 供应链公司一般是不会去参加护网的,因此比较容易攻击





# 打点的技术区分线

1. 对漏洞的原理

   > 知道漏洞的原理, 了解对方在那些对方做了防御

2. 思维的开阔(见识太少)

3. 编程基础

   > 例如: namp 流量特征很明显, 几乎所有的流量设备都能识别

   > namp的流量特征: nmap扫描的时候流量里面带有明显的nmap字样

   

   

   # 提升

   1. 漏洞理解, 不要用工具, XSS用手挖, 杜绝扫描器
   2. 思维(多学习被人挖洞经验, 护网经验, 多动手,虚心向大佬请教)
   3. 加固Python, go , 自己多谢工具

   

   # getshell 工具

   https://github.com/ihebski/DefaultCreds-cheat-sheet

   

   

   # getshell 漏洞总结

   ## 1. shiro

   > 漏洞指纹

   `set-Cookie: rememberMe=deleteMe`

   ![image-20230325151231463](https://raw.githubusercontent.com/QDGSCLOUD/BJYH_picture/main/img/202303251512603.png)

   使用工具**shiro**

   ```
   ./java.exe -jar 工具名(shiroExp-1.3.1-alljar)
   ```

   

   ## 2. struts2

   漏洞指纹：
   Struts
   .action
   .do
   .action!xxxx

   ## 3.Fastjson
   漏洞指纹：
   
   ```
   1. > {"@type":"java.net.Inet4Address", "val":"dnslog"}
      > {"@type":"java.net.Inet6Address", "val":"dnslog"}
      > {"@type":"java.net.InetSocketAddress"{"address":, "val":"dnslog"}}
      > {"@type":"com.alibaba.fastjson.JSONObject", {"@type": "java.net.URL", "val":"dnslog"}}""}
      > {{"@type":"java.net.URL", "val":"dnslog"}:"aaa"}
      > Set[{"@type":"java.net.URL", "val":"dnslog"}]
      > Set[{"@type":"java.net.URL", "val":"dnslog"}
   
   > {{"@type":"java.net.URL", "val":"dnslog"}:0
   ```
   
   





   ## 4.Xstream 反序列化
   漏洞指纹：
   xml
xml 不仅可以xxe, 还能反序列化代码执行



   ## 5.泛微OA Bsh远程代码执行
   漏洞指纹：
   Set-Cookie: ecology_JSessionId=
   ecology
   WorkflowCenterTreeData
/mobile/plugin/SyncUserInfo.jsp



## 6. 通达OA 远程代码执行

   漏洞指纹：
   "/images/tongda.ico">
   Office Anywhere 20xx版 网络智能办公系统
/ispirit/interface/gateway.php



## 7. 通达OA SQL注入

   漏洞指纹
   "/images/tongda.ico">
   Office Anywhere 20xx版 网络智能办公系统
/ispirit/interface/gateway.php



   ## 8. 致远OA A8 htmlofficeservlet getshell 漏洞
   漏洞指纹：
   /seeyon/htmlofficeservlet
   /seeyon/index.jsp
seeyon



   ## 9. 致远OA 帆软报表 seeyonreport 远程代码执行
   漏洞指纹：
   https://seeyoon.com/seeyonreport/ReportServer?op=fs_load&cmd=fs_signin&_=1560911828892
seeyonreport



## 10. Smasti 前台SQL注入

   漏洞指纹：
   SmartBi
smartbi/WEB-INF/lib/smartbi-BIConfig.jar!/smartbi/config/BIConfigService.class



## 11. 深信服VPN远程代码执行

   漏洞指纹：
   Set-Cookie: TWFID=
welcome to ssl vpn



   ## 12. 深信服VPN的口令爆破
   漏洞指纹：
   /por/login_auth.csp?apiversion=1
   sangfor
/cgi-bin/login.cgi?rnd=



   ## 13. Fortigate SSL VPN 文件读取/远程代码执行
   漏洞指纹：
   Fortigate 
4tinet2095866



## 14. Pulse Secure SSL VPN远程代码执行漏洞

   漏洞指纹：
Pulse Secure



## 15. Palo Alto GlobalProtect VPN远程代码执行漏洞

   漏洞指纹
GlobalProtect Portal



   ## 16. Citrix Gateway/ADC 远程代码执行漏洞
   漏洞指纹：
   Citrix Gateway
Citrix Gateway/XSA



   ## 17. Thinkphp
   漏洞指纹：
Thinkphp



## 18. Spring系列

   漏洞指纹：
   X-Application-Context:
"Spring-Framework"



## 19. Phpstudy 后门远程代码

   漏洞指纹：
phpStudy 探针



## 20. Solr系列漏洞

   漏洞指纹:
Solr



   ## 21. Tomcat系列
   漏洞指纹：
   tomcat
   8009
   ajp
\x04\x01\xf4\x00\x15



   ## 22. PHP-fpm 远程代码执行
   漏洞指纹
   Nginx
   PHP
nextcloud



   ## 23. Confluence Wiki 远程代码执行
   漏洞指纹：
Confluence 

   JBoss系列
   漏洞指纹
   Jboss
JBoss



## 23. Websphere 反序列化远程代码执行

   漏洞指纹：
   WebSphere
8880



   ## 23. Jenkins 系列漏洞
   漏洞指纹：
Jenkins



   ## 24. weblog T3
   漏洞指纹：
   weblogic 
   7001
Lcom.tangosol.util.extractor



## 25. redis

   漏洞指纹：
6379

   ## 26. 宝塔
   漏洞指纹：
   888/pma

