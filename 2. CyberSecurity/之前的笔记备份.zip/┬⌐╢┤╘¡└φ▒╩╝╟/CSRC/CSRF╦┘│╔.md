# 什么是CSRF
**跨站请求伪造**（英语：Cross-.site request forgery),也被称为one-click attack或者session riding,通常缩写为，CSRF或者XSRF,是一种挟制用户在当前已登录的 Web应用程序上执行非本意的操作的攻击方法。

# 原理
网站是通过cookie来实现登录功能的。而cookie只要存在浏览器中，那么浏览器在访问这个cookie的服务器的时候，就会自动的携带cookie信息到服务器上去。那么这时候就存在一个漏洞了，如果你访问了一个别有用心或病毒网站，这个网站可以在网页源代码中插入js代码，使用js代码给其他服务器发送请求（比如ICBC的转账请求）。那么因为在发送请求的时候，浏览器会自动的把cookie发送给对应的服务器，这时候相应的服务器（比如ICBC网站），就不知道这个请求是伪造的，就被欺骗过去了。从而达到在用户不知情的情况下，给某个服务器发送了一个请求（比如转账）

> **说白了就是   发起的请求中的某些参数, 可以被推理**

# 产生关键

1. 对资源的写操作(增删改查)
2. 发送的请求内容可被推理
3. 系统没有作相应的判断

**总之:**
> 1. 准备好js文件, 这个文件里的代码能帮助攻击者做一些事情
> 2. 诱导用户点击链接


# 案例
```
某个 url 里面再修改邮箱的时候, 会把修改的内容显示出来, 那么如果将连接中能修改的内容改一下, 
用户不知道的情况下, 修改了内容了吗?
http:// www.kdsfs/./email=old@111 /passward = 222

修改后: 
http:// www.kdsfs/./email=old@111 /passward =111

在用户保持登录的情况下, 原本登录时的cookie还在, 所以将密码改为111 , 用户的账号仍然能够执行,
只要用户点击链接, 它的密码就会在神不知鬼不觉的情况下被更改
```

```
方法一:
在post 型中, 可以尝试将get 参数丢进行, 如果过不行,那就只能按照下面这种方法.
```
> **方法二:**

![image.png](https://cdn.nlark.com/yuque/0/2023/png/26140423/1679120846072-4767a1b7-b655-46a2-aeee-571a5c98f523.png#averageHue=%23f5ebe8&clientId=u46dc345d-31b3-4&from=paste&height=460&id=u92a5f312&originHeight=517&originWidth=1191&originalType=binary&ratio=1.125&rotation=0&showTitle=false&size=325453&status=done&style=none&taskId=u9388db7c-e2be-4da3-bdf6-2be5a94f5c6&title=&width=1058.6666666666667)
![image.png](https://cdn.nlark.com/yuque/0/2023/png/26140423/1679120921678-6e29f27b-dd16-44a7-ae14-eee141fc97be.png#averageHue=%23f6ebea&clientId=u46dc345d-31b3-4&from=paste&height=264&id=ua7cefad0&originHeight=297&originWidth=415&originalType=binary&ratio=1.125&rotation=0&showTitle=false&size=53706&status=done&style=none&taskId=ucd981d38-f6f3-42e2-9848-d220a027057&title=&width=368.8888888888889)
> 这样就可以**直接生成poc,** 到生成的POC中改一下**value 就行**


> 第三种 : 对于有 referer防御的, 可以有一下绕过:

![image.png](https://cdn.nlark.com/yuque/0/2023/png/26140423/1679122982179-0ce6bacd-237d-467c-a03b-2bb9bea8d432.png#averageHue=%23f0f0f0&clientId=u46dc345d-31b3-4&from=paste&height=246&id=u7e9c8c4c&originHeight=277&originWidth=1125&originalType=binary&ratio=1.125&rotation=0&showTitle=false&size=71400&status=done&style=none&taskId=uc2e0f667-d2fe-44c7-8fa6-9f9a0d2430e&title=&width=1000)

